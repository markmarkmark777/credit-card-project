def getSize(
    d
):  #This piece of code right here displays the "enter a credit card number" text descripion from showing.
    size = len(d)
    return size


def getPrefix(number, k):
    index = 0
    saved_numbers = []
    while index < k:
        saved_numbers.append(number[index])
        index = index + 1
        final_str = "".join(saved_numbers)
    return final_str
    #This piece of code right here displays the "enter a credit card number" text descripion from showing.


def prefixMatched(
        number, d):  #This line of code verifies the intial credit card number
    first_Prefix = getPrefix(
        number, 1)  #This line of code verifies the intial credit card number
    second_Prefix = getPrefix(number, 2)
    if d == '4':
        if d == first_Prefix or d == second_Prefix:
            return True
    elif d == '5':
        if d == first_Prefix or d == second_Prefix:
            return True
    elif d == '37':
        if d == first_Prefix or d == second_Prefix:
            return True
    elif d == '6':
        if d == first_Prefix or d == second_Prefix:
            return True
    else:
        return False
    #This line of code verifies the intial credit card number


def getDigit(
        number
):  #This line of code restricts any type of symbol besides numbers.

    answer = int(number[0]) + int(number[1])
    return answer


#This line of code restricts any type of symbol besides numbers.


def sumOfDoubleEvenPlace(
    number
):  #this line of code determinds if the credit card number starts with an even number.

    even_numbers = []
    index = 0
    while index < len(number):
        if index % 2 == 0:
            even_numbers.append(number[index])
        index = index + 1
    return even_numbers
    #this line of code determinds if the credit card number starts with an even number.


def sumOfOddPlace(number):
    odd_numbers = [
    ]  #in line of code determinds if the credit card number starts with an even number.

    index = 0
    while index < len(number):
        if index % 2 != 0:
            odd_numbers.append(int(number[index]))
        index = index + 1
    s = sum(odd_numbers)
    return s


#in line of code determinds if the credit card number starts with an even number.


def isValid(number):
    if getSize(number) >= 13 & getSize(number) <= 16:
        prefix1 = getPrefix(number, 1)
        prefix2 = getPrefix(number, 2)
        matched1 = prefixMatched(number, prefix1)
        matched2 = prefixMatched(number, prefix2)
        if matched1 == True or matched2 == True:
            sum1 = sumOfDoubleEvenPlace(number)
            print(sum1)
            sum2 = sumOfOddPlace(
                number
            )  #this line of code is extremely vital because it varifies the intial code to make sure no number higher then 16 bypass the system.
            print(sum2)
            total = int(sum1) + int(
                sum2
            )  #this line of code is extremely vital because it varifies the intial code to make sure no number higher then 16 bypass the system.
            if total % 10 == 0:
                return True
            else:
                return False
        else:
            return False
    else:
        return True


#this line of code is extremely vital because it varifies the intial code to make sure no number higher then 16 bypass the system.
