import credit

print('Enter a credit card number: ')
number = input()
print(credit.isValid(number))

########
#print(credit.getPrefix(number, 5))
#print(credit.prefixMatched(number, 4))
#print(credit.sumOfDoubleEvenPlace(number))
#print(credit.sumOfOddPlace(number))
#print(credit.getDigit(number))
#print(credit.getLetter(letter))
